package ui.events;

import java.util.EventListener;

public interface TexturedButtonListener extends EventListener {
    public void buttonPressed(TexturedButtonEvent e);
}
