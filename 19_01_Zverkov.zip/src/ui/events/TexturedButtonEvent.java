package ui.events;

import java.util.EventObject;

public class TexturedButtonEvent extends EventObject {

    public TexturedButtonEvent(Object source) {
        super(source);
    }
}
