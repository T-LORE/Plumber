package ui.events;

import java.util.EventListener;

public interface PipeWidgetListener extends EventListener {

    public void rotateClockwise(PipeWidgetEvent event);
}
