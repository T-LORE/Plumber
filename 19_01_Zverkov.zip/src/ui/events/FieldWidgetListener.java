package ui.events;

import java.util.EventListener;

public interface FieldWidgetListener extends EventListener {
    
    public void rotatePipe(FieldWidgetEvent fieldEvent);
}
