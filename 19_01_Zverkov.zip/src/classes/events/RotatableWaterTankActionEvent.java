package classes.events;

public class RotatableWaterTankActionEvent extends WaterActionEvent{

    public RotatableWaterTankActionEvent(Object source) {
        super(source);
    }
}