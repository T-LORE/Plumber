package classes.events;

import java.util.EventObject;
public class DrainActionEvent extends EventObject{

    public DrainActionEvent(Object source) {
        super(source);
    }
}
