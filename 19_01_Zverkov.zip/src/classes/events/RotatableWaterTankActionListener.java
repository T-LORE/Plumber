package classes.events;

public interface RotatableWaterTankActionListener extends WaterTankActionListener {
    public void pipeRotated(RotatableWaterTankActionEvent e);

}
