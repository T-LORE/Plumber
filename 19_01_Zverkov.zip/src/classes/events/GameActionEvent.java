package classes.events;

import java.util.EventObject;

public class GameActionEvent extends EventObject {

    public GameActionEvent(Object source) {
        super(source);
    }
}
