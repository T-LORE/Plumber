package classes.events;

import java.util.EventObject;

public class WaterActionEvent extends EventObject {

    public WaterActionEvent(Object source) {
        super(source);
    }
}
