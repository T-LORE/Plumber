package classes.entities.water_tanks;


public class Pipe extends AbstractRotatableWaterTanks {
    
    public Pipe() {
        super();
    }
    
}
